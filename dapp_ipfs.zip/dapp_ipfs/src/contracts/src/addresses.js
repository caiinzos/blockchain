const addresses = {
  fichajes: "0xA35a90eCf3f62E6F162506753A8f7B5Fc5c01Fdf", 
};

export default addresses;
