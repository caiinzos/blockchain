import fichajesContract from "./abis/FichajeContract.json";

const abis = {
  fichajes: fichajesContract,
};

export default abis;
