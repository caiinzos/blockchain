import React, { useEffect, useState } from "react";
import './App.css';
import { create } from 'kubo-rpc-client'
import { ethers } from "ethers"
import { Buffer } from "buffer"

import logo from "./ethereumLogo.png"
import { addresses, abis } from "./contracts"

const defaultProvider = new ethers.providers.Web3Provider(window.ethereum);
const fichajeContract = new ethers.Contract(
  addresses.fichajes,
  abis.fichajes,
  defaultProvider
);

function App() {
  const [file, setFile] = useState(null);
  const [fichajeId, setFichajeId] = useState("");
  const [documentos, setDocumentos] = useState([]);
  const [fichajes, setFichajes] = useState([]);
  const [nuevoFichaje, setNuevoFichaje] = useState({
    nombreJugador: "",
    edad: "",
    clubOrigen: "",
    clubDestino: "",
    valorTransferencia: ""
  });

  useEffect(() => {
    window.ethereum.enable();
    cargarFichajes();
  }, []);

  const cargarFichajes = async () => {
    try {
      const total = await fichajeContract.totalFichajes();
      const fichajesArray = [];
      
      for (let i = 1; i <= total.toNumber(); i++) {
        const fichaje = await fichajeContract.obtenerFichaje(i);
        fichajesArray.push({
          id: i,
          nombreJugador: fichaje.nombreJugador,
          edad: fichaje.edad.toNumber(),
          clubOrigen: fichaje.clubOrigen,
          clubDestino: fichaje.clubDestino,
          valorTransferencia: ethers.utils.formatEther(fichaje.valorTransferencia),
          aprobado: fichaje.aprobado,
          ipfsHash: fichaje.ipfsHash,
          subidoPor: fichaje.subidoPor
        });
      }
      
      setFichajes(fichajesArray);
    } catch (error) {
      console.log("Error cargando fichajes:", error);
    }
  };

  const subirDocumentoFichaje = async (hashIPFS, idFichaje) => {
    try {
      const contractWithSigner = fichajeContract.connect(defaultProvider.getSigner());
      const tx = await contractWithSigner.subirDocumentoFichaje(idFichaje, hashIPFS);
      await tx.wait();
      console.log("Documento subido:", tx);
      return true;
    } catch (error) {
      console.error("Error subiendo documento:", error);
      throw error;
    }
  };

  const registrarNuevoFichaje = async () => {
    try {
      if (!nuevoFichaje.nombreJugador || !nuevoFichaje.edad || !nuevoFichaje.clubOrigen || 
          !nuevoFichaje.clubDestino || !nuevoFichaje.valorTransferencia) {
        alert("Por favor, completa todos los campos");
        return;
      }

      const contractWithSigner = fichajeContract.connect(defaultProvider.getSigner());
      const tx = await contractWithSigner.registrarFichaje(
        nuevoFichaje.nombreJugador,
        parseInt(nuevoFichaje.edad),
        nuevoFichaje.clubOrigen,
        nuevoFichaje.clubDestino,
        ethers.utils.parseEther(nuevoFichaje.valorTransferencia)
      );
      
      await tx.wait();
      console.log("Fichaje registrado:", tx);
      alert("✅ Fichaje registrado correctamente");
      
      // Limpiar formulario y recargar lista
      setNuevoFichaje({
        nombreJugador: "",
        edad: "",
        clubOrigen: "",
        clubDestino: "",
        valorTransferencia: ""
      });
      
      await cargarFichajes();
      
    } catch (error) {
      console.error("Error registrando fichaje:", error);
      alert("❌ Error al registrar fichaje: " + error.message);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (!file) {
        alert("Por favor, selecciona un archivo primero");
        return;
      }
      
      if (!fichajeId) {
        alert("Por favor, ingresa un ID de fichaje");
        return;
      }

      console.log("Conectando a IPFS...");
      const client = await create('http://127.0.0.1:5001');
      
      console.log("Subiendo archivo a IPFS...");
      const result = await client.add(file);
      
      console.log("Archivo subido. CID:", result.cid.toString());
      
      console.log("Guardando hash en blockchain...");
      await subirDocumentoFichaje(result.cid.toString(), parseInt(fichajeId));
      
      // Actualizar lista de documentos
      setDocumentos(prev => [...prev, {
        id: fichajeId,
        hash: result.cid.toString(),
        timestamp: new Date().toLocaleString(),
        url: `http://127.0.0.1:8080/ipfs/${result.cid.toString()}`
      }]);
      
      alert(`✅ Documento subido exitosamente!\n\nFichaje ID: ${fichajeId}\nHash IPFS: ${result.cid.toString()}`);
      
      await cargarFichajes();
      
    } catch (error) {
      console.error("Error completo:", error);
      alert("❌ Error: " + error.message);
    }
  };

  const retrieveFile = (e) => {
    const data = e.target.files[0];
    const reader = new window.FileReader();
    reader.readAsArrayBuffer(data);
    reader.onloadend = () => {
      setFile(Buffer(reader.result));
    }
    e.preventDefault();
  };

  const consultarFichaje = async (id) => {
    try {
      const fichaje = await fichajeContract.obtenerFichaje(id);
      const info = `
Fichaje ID: ${id}
Jugador: ${fichaje.nombreJugador}
Edad: ${fichaje.edad}
Club Origen: ${fichaje.clubOrigen}
Club Destino: ${fichaje.clubDestino}
Valor: ${ethers.utils.formatEther(fichaje.valorTransferencia)} ETH
Aprobado: ${fichaje.aprobado ? '✅ Sí' : '❌ No'}
Hash IPFS: ${fichaje.ipfsHash || 'No subido'}
      `;
      alert(info);
    } catch (error) {
      console.error("Error consultando fichaje:", error);
      alert("Error al consultar fichaje: " + error.message);
    }
  };

  const aprobarFichaje = async (id) => {
    try {
      const contractWithSigner = fichajeContract.connect(defaultProvider.getSigner());
      const tx = await contractWithSigner.aprobarFichaje(id);
      await tx.wait();
      alert(`✅ Fichaje ${id} aprobado correctamente`);
      await cargarFichajes();
    } catch (error) {
      console.error("Error aprobando fichaje:", error);
      alert("Error al aprobar fichaje: " + error.message);
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <h1>⚽ Sistema de Fichajes con IPFS</h1>
        
        {/* Formulario de Registro de Fichaje */}
        <div className="section">
          <h2>📝 Registrar Nuevo Fichaje</h2>
          <div className="form-group">
            <input 
              type="text" 
              placeholder="Nombre del Jugador"
              value={nuevoFichaje.nombreJugador}
              onChange={(e) => setNuevoFichaje({...nuevoFichaje, nombreJugador: e.target.value})}
            />
            <input 
              type="number" 
              placeholder="Edad"
              value={nuevoFichaje.edad}
              onChange={(e) => setNuevoFichaje({...nuevoFichaje, edad: e.target.value})}
            />
            <input 
              type="text" 
              placeholder="Club Origen"
              value={nuevoFichaje.clubOrigen}
              onChange={(e) => setNuevoFichaje({...nuevoFichaje, clubOrigen: e.target.value})}
            />
            <input 
              type="text" 
              placeholder="Club Destino"
              value={nuevoFichaje.clubDestino}
              onChange={(e) => setNuevoFichaje({...nuevoFichaje, clubDestino: e.target.value})}
            />
            <input 
              type="text" 
              placeholder="Valor Transferencia (ETH)"
              value={nuevoFichaje.valorTransferencia}
              onChange={(e) => setNuevoFichaje({...nuevoFichaje, valorTransferencia: e.target.value})}
            />
            <button onClick={registrarNuevoFichaje} className="btn btn-primary">
              📄 Registrar Fichaje
            </button>
          </div>
        </div>

        {/* Formulario de Subida de Documentos */}
        <div className="section">
          <h2>📎 Subir Documento de Fichaje a IPFS</h2>
          <form className="form" onSubmit={handleSubmit}>
            <input 
              type="number" 
              placeholder="ID del Fichaje"
              value={fichajeId}
              onChange={(e) => setFichajeId(e.target.value)}
            />
            <input type="file" name="data" onChange={retrieveFile} />
            <button type="submit" className="btn btn-success">
              ☁️ Subir Documento a IPFS
            </button>
          </form>
        </div>

        {/* Lista de Fichajes */}
        <div className="section">
          <h2>📋 Fichajes Registrados ({fichajes.length})</h2>
          <div className="fichajes-list">
            {fichajes.map((fichaje) => (
              <div key={fichaje.id} className="fichaje-card">
                <h3>{fichaje.nombreJugador} (ID: {fichaje.id})</h3>
                <p>Edad: {fichaje.edad} | {fichaje.clubOrigen} → {fichaje.clubDestino}</p>
                <p>Valor: {fichaje.valorTransferencia} ETH</p>
                <p>Estado: {fichaje.aprobado ? '✅ Aprobado' : '⏳ Pendiente'}</p>
                <p>IPFS: {fichaje.ipfsHash ? '✅ Subido' : '❌ No subido'}</p>
                <div className="actions">
                  <button onClick={() => consultarFichaje(fichaje.id)} className="btn btn-info">
                    🔍 Consultar
                  </button>
                  {!fichaje.aprobado && (
                    <button onClick={() => aprobarFichaje(fichaje.id)} className="btn btn-warning">
                      ✅ Aprobar
                    </button>
                  )}
                  {fichaje.ipfsHash && (
                    <a 
                      href={`http://127.0.0.1:8080/ipfs/${fichaje.ipfsHash}`} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="btn btn-secondary"
                    >
                      📄 Ver Documento
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Documentos Subidos Recientemente */}
        {documentos.length > 0 && (
          <div className="section">
            <h2>📤 Documentos Subidos Recientemente</h2>
            <div className="documentos-list">
              {documentos.map((doc, index) => (
                <div key={index} className="documento-card">
                  <p><strong>Fichaje ID:</strong> {doc.id}</p>
                  <p><strong>Hash IPFS:</strong> {doc.hash}</p>
                  <p><strong>Fecha:</strong> {doc.timestamp}</p>
                  <a href={doc.url} target="_blank" rel="noopener noreferrer" className="btn btn-link">
                    🔗 Ver Documento
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}
      </header>
    </div>
  );
}

export default App;